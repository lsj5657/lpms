import React, { useRef, useEffect, useState, useContext } from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
  Chart as ChartJS,
  LinearScale,
  PointElement,
  LineElement,
  Tooltip,
  Legend,
  LogarithmicScale,
} from "chart.js";
import { NowResultConntext } from "../App";
import "./Channel.css";
import axios from "axios";
import { Line } from "react-chartjs-2";

ChartJS.register(
    LinearScale,
    PointElement,
    LineElement,
    Tooltip,
    Legend,
    LogarithmicScale
);

const graphoptions = {
  responsive: true,
  plugins: {
    legend: {
      display: false,
    },
    tooltip: {
      enabled: false,
    },
  },
  scales: {
    x: {
      type: "linear",
      position: "bottom",
    },
    y: {
      type: "linear",
      position: "left",
    },
  },
};

const dataTranslate = (lowData) => {
  if (!lowData || lowData.length === 0) return { datasets: [] };

  const highData = {
    datasets: [
      {
        data: lowData.map((point) => ({ x: point.x, y: point.y })),
        fill: false,
        backgroundColor: "rgba(75,192,192,0.4)",
        borderColor: "rgba(75,192,192,1)",
        pointRadius: 0.5,
        borderWidth: 0.5,
      },
    ],
  };
  return highData;
};

const channeloptions = [
  { value: 0, label: "V101" },
  { value: 1, label: "V102" },
  { value: 2, label: "V103" },
  { value: 3, label: "V104" },
  { value: 4, label: "V105" },
  { value: 5, label: "V106" },
  { value: 6, label: "V107" },
  { value: 7, label: "V108" },
  { value: 8, label: "V109" },
  { value: 9, label: "V110" },
  { value: 10, label: "V111" },
  { value: 11, label: "V112" },
  { value: 12, label: "V113" },
  { value: 13, label: "V114" },
  { value: 14, label: "V115" },
  { value: 15, label: "V116" },
  { value: 16, label: "V117" },
  { value: 17, label: "V118" },
];

const findValueByLabel = (label) => {
  const option = channeloptions.find((option) => option.label === label);
  return option ? option.value : null;
};

const Channel = () => {
  const params = useParams();
  const navigate = useNavigate();
  const nowResult = useContext(NowResultConntext);
  const canvasRef = useRef(null);
  const [selectedCh, setSelectedCh] = useState([
    findValueByLabel(params.Channel),
  ]);
  const [isLogScale, setIsLogScale] = useState(false);
  const [originalImagePath, setOriginalImagePath] = useState("");

  useEffect(() => {
    const updateSelectedCh = () => {
      setSelectedCh(findValueByLabel(params.Channel));
    };
    updateSelectedCh();
  }, [params.Channel]);

  const [TimeData, setGraphTimeData] = useState([]);
  const [FrequencyData, setGraphFrequencyData] = useState([]);

  const [data, setData] = useState({
    imagePath: "",
    aiResult: "",
    aiProbability: "",
    showResultPage: false,
  });

  useEffect(() => {
    axios
        .get(`/api/time/${params.Remark}?selectedCh=${selectedCh}`)
        .then((res) => {
          setGraphTimeData(res.data);
        })
        .catch((error) => {
          console.error("Error fetching time data:", error);
          setGraphTimeData([]);
        });
  }, [params.Remark, selectedCh]);

  useEffect(() => {
    axios
        .get(`/api/freq/${params.Remark}?selectedCh=${selectedCh}`)
        .then((res) => {
          setGraphFrequencyData(res.data);
        })
        .catch((error) => {
          console.error("Error fetching frequency data:", error);
          setGraphFrequencyData([]);
        });
  }, [params.Remark, selectedCh]);

  const handleButtonClick = () => {
    axios
        .get(`/api/result/${nowResult.Remark}`, { params: { selectedCh } })
        .then((res) => {
          console.log(res.data);
          const temdata = {
            aiResult: res.data.aiResult,
            aiProbability: res.data.aiProbability,
            showResultPage: true,
            imagePath: res.data.imagePath,
          };
          setOriginalImagePath(res.data.imagePath); // 원본 이미지 경로 저장
          setData((prevData) => {
            const newData = {
              ...prevData,
              ...temdata,
            };
            console.log(newData);
            return newData;
          });
        })
        .catch((error) => {
          console.error("Error fetching result data:", error);
        });
  };

  useEffect(() => {
    console.log(data);
  }, [data]);

  const toggleLogScale = () => {
    setIsLogScale(!isLogScale);
  };

  const graphFrequencyOptions = {
    ...graphoptions,
    scales: {
      ...graphoptions.scales,
      y: {
        ...graphoptions.scales.y,
        type: isLogScale ? "logarithmic" : "linear",
      },
    },
  };

  const resizeImage = (imageSrc, callback) => {
    const img = new Image();
    img.src = imageSrc;
    img.onload = () => {
      const canvas = canvasRef.current;
      if (canvas) {
        const ctx = canvas.getContext("2d");
        canvas.width = 300;
        canvas.height = 300;
        ctx.drawImage(img, 0, 0, 300, 300);
        const resizedImageURL = canvas.toDataURL();
        callback(resizedImageURL);
      }
    };
  };

  useEffect(() => {
    if (data.imagePath) {
      resizeImage(data.imagePath, (resizedImage) =>
          setData((prevData) => ({
            ...prevData,
            imagePath: resizedImage,
          }))
      );
    }
  }, [data.imagePath]);

  const getResultClass = (s) => {
    if (s === "AVAILABLE") return "available";
    if (s === "True") return "true";
    if (s === "False") return "false";
    return "";
  };

  const handleImageClick = () => {
    navigate("/showimage", { state: { imagePath: originalImagePath } }); // 원본 이미지 경로 사용
  };

  return (
      <>
        <div className="Channel">
          <div className="Top">
            <div className="LeftSide">
              <select
                  className="select"
                  value={selectedCh}
                  onChange={(e) => setSelectedCh(e.target.value)}
              >
                <option hidden>{nowResult.Channel}</option>
                {channeloptions.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                ))}
              </select>
              <div>Filename: {params.Remark}</div>
            </div>
            <button onClick={handleButtonClick} className="Button">
              판정하기
            </button>
          </div>
          <div className="Graphs">
            <div className="Graph">
              <div className="Title">TIME</div>
              <div>
                <Line data={dataTranslate(TimeData)} options={graphoptions} />
              </div>
            </div>
            <div className="Graph">
              <div className="Title">
                <div>FREQUENCY</div>
                <button className="LogLinear" onClick={toggleLogScale}>
                  {isLogScale ? "Log" : "Linear"}
                </button>
              </div>

              <div>
                <Line
                    data={dataTranslate(FrequencyData)}
                    options={graphFrequencyOptions}
                />
              </div>
            </div>
          </div>
        </div>
        {data.showResultPage &&
            data.imagePath &&
            data.aiResult !== "" &&
            data.aiProbability !== "" && (
                <div className="ResultImage">
                  <canvas ref={canvasRef} style={{display: "none"}}/>
                  <div style={{cursor: 'pointer'}}>
                    <img
                        src={data.imagePath}
                        alt="Result"
                        onClick={handleImageClick}
                    />
                  </div>
                  <div className="Text">
                    <div>{nowResult.Remark} 파일 AI 판정 결과:</div>
                    <div
                        className={`result ${getResultClass(
                            data.aiResult ? "True" : "False"
                        )}`}
                    >
                      Result: {data.aiResult ? "True" : "False"}
                    </div>
                    <div className={`result ${"available"}`}>
                      Impact Probability:{" "}
                      {(data.aiProbability * 100).toFixed(3)}
                      %
                    </div>
                  </div>
                </div>
            )}
      </>
  );
};

export default Channel;
