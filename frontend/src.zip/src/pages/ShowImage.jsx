// components/ShowImage.jsx
import React from "react";
import { useLocation } from "react-router-dom";
import "./ShowImage.css";
// import notYet from "../assets/notYet.png";

const ShowImage = () => {
    const location = useLocation();
    const { imagePath } = location.state || {};

    return (
        <div className="ShowImage">
            <div className="Title">판정 결과</div>
            {imagePath ? (
                <div className="Image-wrapper">
                    <img src={imagePath} alt="Full View" className="Full-image" />
                </div>
            ) : (
                <p>No image to display</p>
            )}
        </div>
      /*  <div className="container">
            <div className="title">판정 결과</div>

                <div className="image-wrapper">
                    <img
                        src={imagePath || notYet}
                        alt="Full View"
                        className="full-image"
                    /></div>

        </div>*/
    );
};

export default ShowImage;
