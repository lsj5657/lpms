import Header from "../components/Header";
import EventLog from "../components/EventLog";
import { useContext } from "react";
import { ChannelInfo } from "../App";
import { ResultStatusContextController } from "../App";
const Home = () => {
  const data = useContext(ChannelInfo);
  const setResultStatus = useContext(ResultStatusContextController);

  setResultStatus("NOTAVAILABLE");
  return (
    <>
      <Header text={"Event Log"} />
      <EventLog data={data} />
    </>
  );
};
export default Home;
