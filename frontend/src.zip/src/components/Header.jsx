import "./Header.css";

const Header = ({ text }) => {
  return (
    <>
      <div className="Header">{text}</div>
    </>
  );
};

export default Header;
