import { useState } from "react";
import EventLogItem from "./EventLogItem";
import "./EventLog.css";
import Item from "./Item";

const EventLog = ({ data }) => {
  const [sortType, setSortType] = useState("latest");
  const [statusFilter, setStatusFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");

  const onChangeSortType = (e) => {
    setSortType(e.target.value);
  };

  const onChangeStatusFilter = (e) => {
    setStatusFilter(e.target.value);
  };

  const onChangeTypeFilter = (e) => {
    setTypeFilter(e.target.value);
  };

  const parseDateString = (dateString) => {
    const parts = dateString.split(/[- :.]/);
    const dateObject = new Date(
        parts[0],
        parts[1] - 1,
        parts[2],
        parts[3],
        parts[4],
        parts[5],
        parts[6]
    );
    return dateObject;
  };

  const getSortedData = () => {
    return data
        .slice()
        .sort((a, b) => {
          const date1 = parseDateString(a.Time);
          const date2 = parseDateString(b.Time);
          if (sortType === "latest") {
            return date1 > date2 ? -1 : 1;
          } else {
            return date1 < date2 ? -1 : 1;
          }
        })
        .filter((item) => {
          if (
              statusFilter !== "all" &&
              (item.Status ? "True" : "False") !== statusFilter
          ) {
            return false;
          }
          if (typeFilter !== "all" && item.Type !== typeFilter) {
            return false;
          }
          return true;
        });
  };

  const sortedData = getSortedData();

  return (
      <div className="EventLog">
        <div className="menu_bar">
          <select value={sortType} onChange={onChangeSortType}>
            <option value={"latest"}>LATEST</option>
            <option value={"oldest"}>OLDEST</option>
          </select>
          <select value={statusFilter} onChange={onChangeStatusFilter}>
            <option value={"all"}>ALL</option>
            <option value={"True"}>TRUE</option>
            <option value={"False"}>FALSE</option>
          </select>
          <select value={typeFilter} onChange={onChangeTypeFilter}>
            <option value={"all"}>ALL</option>
            <option value={"Dual"}>DUAL</option>
            <option value={"Fixed"}>FIXED</option>
            <option value={"Floating"}>FLOATING</option>
            <option value={"NA"}>NA</option>
          </select>
        </div>
        <div className="menu_name">
          <Item text={"Date"} attribute={"Date"} />
          <Item text={"Event Channel"} attribute={"Channel"} />
          <Item text={"Status"} attribute={"Status"} />
          <Item text={"Type"} attribute={"Type"} />
          <Item text={"Remark"} attribute={"Remark"} />
        </div>
        <div className="list_wrapper">
          {sortedData.map((item) => (
              <EventLogItem key={item.Remark} {...item} />
          ))}
        </div>
      </div>
  );
};

export default EventLog;
