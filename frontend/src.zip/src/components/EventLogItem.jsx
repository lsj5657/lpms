import { useNavigate } from "react-router-dom";
import { useState, useContext } from "react";
import {
  NowResultConntextController,
  ResultStatusContextController,
} from "../App";
import "./EventLogItem.css";
import Item from "./Item";

const EventLogItem = ({ Time, Channel, Status, Type, Remark }) => {
  const nav = useNavigate();
  const setNowResult = useContext(NowResultConntextController);
  const setResultStatus = useContext(ResultStatusContextController);

  const handleClick = () => {
    setNowResult({ Time, Channel, Status, Type, Remark });
    setResultStatus("AVAILABLE");
    nav(`channel/${Remark}`);
  };

  let statusText;
  if (Status === "Loading") {
    statusText = "Loading";
  } else {
    statusText = Status ? "True" : "False";
  }

  return (
      <>
        <div className="EventLogItem" onClick={handleClick}>
          <Item text={Time} attribute={"Date"} />
          <Item text={Channel} attribute={"Channel"} />
          <Item text={statusText} attribute={"Status"} />
          <Item text={Type} attribute={"Type"} />
          <Item text={Remark} attribute={"Remark"} />
        </div>
      </>
  );
};

export default EventLogItem;
