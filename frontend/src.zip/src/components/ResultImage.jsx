/*
import "./ResultImage.css";
import { useRef, useContext, useEffect, useState } from "react";
import {
  NowResultConntext,
  ResultStatusContextController,
  ResultStatusContext,
} from "../App";
import resultImage from "../../../hi.png";
import axios from "axios";

// Imagefetch 안되면 여기 수정
const ResultImage = () => {
  const setResultStatus = useContext(ResultStatusContextController);
  const nowResult = useContext(NowResultConntext);
  const resultStatus = useContext(ResultStatusContext);
  const [imageResult, setImageResult] = useState();
  const canvasRef = useRef(null);
  const [probaility, setProbaility] = useState(0.0);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await axios.get(`/api/result/${nowResult.Remark}`);
        const [r, p] = res.data;
        setResultStatus(r);
        setProbaility(p);
        setImageResult(resultImage);
      } catch (error) {
        console.error("Error fetching result data:", error);
      }
    };
    fetchData();
  }, [nowResult.Remark, setResultStatus]);

  const resizeImage = (imageSrc, callback) => {
    const img = new Image();
    img.src = imageSrc;
    img.onload = () => {
      const canvas = canvasRef.current;
      const ctx = canvas.getContext("2d");

      canvas.width = 500;
      canvas.height = 500;

      ctx.drawImage(img, 0, 0, 500, 500);

      const resizedImageURL = canvas.toDataURL();
      callback(resizedImageURL);
    };
  };

  useEffect(() => {
    resizeImage(resultImage, setImageResult);
  }, []);

  const getResultClass = (s) => {
    if (s === "AVAILABLE") return "available";
    if (s === "True") return "true";
    if (s === "False") return "false";
    return "";
  };

  return (
      <>
        <div className="ResultImage">
          <canvas ref={canvasRef} style={{ display: "none" }} />
          <div>
            <img src={imageResult} alt="Result" />
          </div>
          <div className="Text">
            <div>{nowResult.Remark} 파일 판정 결과:</div>
            <div className={`result ${getResultClass(resultStatus)}`}>
              {resultStatus}
              {probaility}
            </div>
          </div>
        </div>
      </>
  );
};

export default ResultImage;
*/
